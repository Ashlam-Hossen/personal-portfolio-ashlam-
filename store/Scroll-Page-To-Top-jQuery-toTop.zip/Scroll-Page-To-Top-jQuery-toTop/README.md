# toTop
jQuery plugin for scroll page to top


```javascript
$('.totop').tottTop({
    scrollTop: 1000, // The height of the document which will show a button
    duration: 1000, // scroll animation duration
    scrtollTopBtnDuration: 400 // button show animation duration
});
```
